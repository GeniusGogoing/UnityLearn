---------------------------------------------------------------------
---@author      ${USER}
---@create      ${YEAR}-${MONTH}-${DAY} ${TIME}
  
---@class       ${FILE_NAME}
local Class = class("${FILE_NAME}", PureMVC.Mediator.new())

function Class:OnRegister()
	local tr = self.mViewComponent.transform
	
	self:RegistHandler()
end

--region 初始化

--endregion

--region 刷新

--endregion

--region 事件处理

--endregion

--region 消息处理
function Class:ListNotificationInterests()
    return {
    }
end

function Class:RegistHandler()
self.handlerTable = {}
    self.handlerMetaTable = {}
    self.handlerMetaTable.__index = function(tab, key)
        return
        function(data)
            printError("panel not handle notification: " .. key)
            return
        end
    end
    setmetatable(self.handlerTable, self.handlerMetaTable)
end

function Class:HandleNotification(notification)
    self.handlerTable[notification[1]](notification[2])
end
--endregion

--region 面板清理相关
function Class:OnClosePanel()

end

function Class:OnRemove()

end
--endregion

return Class