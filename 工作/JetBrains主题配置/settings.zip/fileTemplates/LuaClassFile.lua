---------------------------------------------------------------------
---@author      ${USER}
---@create      ${YEAR}-${MONTH}-${DAY} ${TIME}
  
---@class       ${FILE_NAME}
local Class = class("${FILE_NAME}", UIBase)
function Class:ctor(gameObject)
	self.gameObject = gameObject
	local tr = self.gameObject.transform
end

function Class:Clear()
	self.gameObject:Recycle()
end

return Class