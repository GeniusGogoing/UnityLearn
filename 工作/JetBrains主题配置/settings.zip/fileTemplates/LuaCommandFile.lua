---------------------------------------------------------------------
---@author      ${USER}
---@create      ${YEAR}-${MONTH}-${DAY} ${TIME}
  
---@class       ${FILE_NAME}
local Class = class("${FILE_NAME}", PureMVC.Command.new())

function Class:Execute(notification)

end

return Class