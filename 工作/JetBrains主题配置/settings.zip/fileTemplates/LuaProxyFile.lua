---------------------------------------------------------------------
---@author      ${USER}
---@create      ${YEAR}-${MONTH}-${DAY} ${TIME}
  
---@class       ${FILE_NAME}
local Class = class("${FILE_NAME}", PureMVC.Proxy.new())

function Class:OnRegister()
	
end

--region C2S
function Class:Func()
    if GameDefine.CannotClick() then
        return
    end
    HarryRedLog("Func")
    GameDefine.SetProcessState(true)
    local msg = pb.GetFunc()
    
    local modId, funId = GetMSGID("mod", "act")
    SendMSGToServer(modId, funId, msg)
end
--endregion

--region S2C
function Class:ReturnFunc(pb)
    HarryRedLog("ReturnFunc")
    GameDefine.SetProcessState(false)
    local msg = pb.ReturnFunc()
    msg:ParseFromString(pb)
    
    if msg.resultInfo.enumValue == ProtoResultEnumModelData.success then
        SendNotification({ CMD_WAR_READY_GET_INFO_DONE, self.deployDataList })
    else
        ProtolResultProcess(msg.resultInfo)
    end
end
--endregion

--region getters

--endregion

--region setters

--endregion

return Class